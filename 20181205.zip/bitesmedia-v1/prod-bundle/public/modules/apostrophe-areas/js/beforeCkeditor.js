// Tell ckeditor where to load the rest of itself from dynamically.
// Necessary because the main ckeditor.js is included in minification,
// so its relative path is no good.
CKEDITOR_BASEPATH = apos.prefix + '/modules/apostrophe-areas/js/vendor/ckeditor/';
