apos.define('apostrophe-files', {
  extend: 'apostrophe-pieces',
  construct: function(self, options) {
    apos.files = self;
  }
});
