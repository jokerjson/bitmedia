apos.define('apostrophe-images', {
  extend: 'apostrophe-pieces',
  construct: function(self, options) {
    apos.images = self;
  }
});
