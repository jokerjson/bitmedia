import React, { Component } from 'react';
import { observer } from 'mobx-react';
import './style.less';

export default observer (class CheckPanel extends Component {
    constructor(props, context) {
        super(props, context);
        console.log(this.props);
        this.state = {
            status:this.props.status
        };
    }
    check = (result) => {
        this.setState({
            status:result
        })
        let results = [result,this.props._index];
        this.props.onCheck(results);
    }
    render() {
        const state = this.state;
        return (
            <div className = "check_panel">
                {
                    state.status === undefined ?
                        (<div className = "check_panel" id = { "check_panel" + this.props._index }>
                            <div className = "btn_true" onClick = {() => this.check(true)} />
                            <div className = "btn_false" onClick = {() => this.check(false)} />
                        </div>): null
                }

                {
                    state.status === true ? 
                    (<div className = "check_panel" id = { "check_panel"+this.props._index }>
                         <div className = "correct_label">Correct</div>
                     </div>): null
                }

                {
                    state.status === false ? 
                     (<div className = "check_panel" id = { "check_panel"+this.props._index }>
                         <div className = "incorrect_label">Incorrect</div>
                     </div>): null
                }
            </div>
        )
    }
})