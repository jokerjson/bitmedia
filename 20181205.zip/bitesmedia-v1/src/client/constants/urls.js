export const BASE_URL = '';
export const BASE_PATH = '/api/v1';